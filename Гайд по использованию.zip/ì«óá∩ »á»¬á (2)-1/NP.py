import pygame
pygame.init()
width, height = size = (1280, 1024)
levelname = input()
levelname += '.osu'
pygame.mixer.init()
life = 100
screen1 = pygame.Surface(size)
cursor = pygame.image.load("cursor.png")
cursor = pygame.transform.scale(cursor, (54,54))
pygame.mouse.set_visible(False)
beatmap = []
with open(levelname, "r") as f:
    lines = f.readlines()
    bgimg = lines[0]
    music = lines[1]
    for beat in lines[2:]:

        Ltime, x, y = beat.split('|')
        Ltime, x, y = int(Ltime), int(x), int(y)
        beatmap += [(Ltime, x, y)]



color = [0,0,255]
score = 0
r = 10
time = 0
bgimg = bgimg.strip()
music = music.strip()
image = pygame.image.load(bgimg)
image = pygame.transform.scale(image, (size[0],size[1]))
krest = pygame.image.load('krest.png')
scale = pygame.transform.scale(krest, (60,60))
gal = pygame.image.load('tr.png')
scale_g = pygame.transform.scale(gal, (60,60))
pygame.mixer.music.load(music)
    
clock = pygame.time.Clock()
running = True
d = False
class circle:
    def __init__(self,x,y):
        self.clicked = False
        self.r = 60
        self.realR = 40
        self.rr = 50
        self.size = 1
        self.ltime = 0
        self.color = [0, 0, 255]
        self.colorc = [0, 0, 0]
        self.coloro = [255, 255, 255]
        self.clicked = False
        self.d = True
        self.x = x
        self.y = y
        self.alpha = 0
        self.n = 0
        self.rect = pygame.Rect(self.x - self.realR,self.y - self.realR,self.realR*2,self.realR*2)
        self.dd = False
    
    def change_size(self, nsize):
        self.size = nsize ** 0.5
        self.rr = 50 + int(30*(self.size - 1))
    def draw_circle  (self):
        global life
        if self.d and (time - self.ltime) == 1:
            self.dd = True
            self.ltime = time
            pygame.draw.circle(screen1, self.colorc,(self.x,self.y), int(30*self.size))
            pygame.draw.circle(screen1, self.coloro,(self.x,self.y),self.rr, 3)
            if self.color[2] > 255//13 :

                self.color[2] -= 12
                self.color[1] += 12
                self.colorc[0] = int(self.color[0]*self.alpha)
                self.colorc[1] = int(self.color[1]*self.alpha)
                self.colorc[2] = int(self.color[2]*self.alpha)
                self.rr -= 1
                self.alpha += 0.05
            

            else:

                self.n += 1
                
                if self.n > 70:
                    self.alpha -= 0.09
                else:
                    self.alpha = 1
                    
                self.colorc[0] = int(self.color[0]*self.alpha)
                self.colorc[1] = int(self.color[1]*self.alpha)
                self.colorc[2] = int(self.color[2]*self.alpha)
                self.coloro[0] = int(255*self.alpha)
                self.coloro[1] = int(255*self.alpha)
                self.coloro[2] = int(255*self.alpha)
            self.r -= 1
            if self.r < 2:
                
                self.d = False
                self.alpha = 0
                self.coloro = [255, 255, 255]
                self.n = 0
                self.dd = False
                if self.clicked == False:
                    life -= 20
mpos = [-100,-100]
krt = 0

draw_krest = False
gl = False
pygame.mixer.music.play(1)
beats = []
for beat in beatmap:
    beats += [circle(beat[1], beat[2])]
    beats[-1].ltime = beat[0]
poz = []
scale_g.set_colorkey((255, 255, 255))
screen1.fill((0, 0, 0))
screen1.blit(image,(0,0))
while running:
    screen1.fill((0, 0, 0))
    #screen1.blit(image,(0,0))
    poz = []
    poz.append(pygame.mouse.get_pos()[0])
    poz.append(pygame.mouse.get_pos()[1])
    
    poz[0] = poz[0] - 27
    poz[1] = poz[1] - 27    
    time += 1
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            mpos = ()
            f = False
            mpos = event.pos
            for i in beats:
                if i.rect.collidepoint(event.pos) and i.dd and not(i.clicked):
                    i.clicked = True
                    f = True
                    break
            if f:
                life += 5
                mpos = event.pos
                gl = True
            else:
                life -= 5
                draw_krest = True                
                mpos = event.pos
    for beat in beats:
        beat.draw_circle()
    if draw_krest:
        if krt < 20:
            screen1.blit(scale, (mpos[0] - 25,mpos[1] - 25))
            krt += 1
        else:
            krt = 0
            draw_krest = False
    if gl:
        if krt < 20:
            screen1.blit(scale_g, (mpos[0] - 25,mpos[1] - 25))
            krt += 1
        else:
            krt = 0
            gl = False
    if pygame.mouse.get_focused():
        cursor.set_alpha(0)
        screen1.blit(cursor, poz)  
    
    pygame.display.flip()
    if life < 0:
        running = False
    clock.tick(60)
    
pygame.quit()
