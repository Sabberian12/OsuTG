import pygame
pygame.init()
life = 100
asd = str(input('������� ����� �� 1 �� 5 '))
pygame.mixer.init()
width, height = size = (1280, 1024)
window = pygame.display.set_mode((1280, 1024))
screen = pygame.Surface((1280, 1024))
mainscreen = screen
screen1 = pygame.Surface(size)
MusicLevels = []
dfg = 'data/cursor' + asd + '.png'
cursor = pygame.image.load(dfg)
levelname = None
cursor = pygame.transform.scale(cursor, (54,54))
pygame.mouse.set_visible(False)
playing = False
def rot_center(image, rect, angle):
        rot_image = pygame.transform.rotate(image, angle)
        rot_rect = rot_image.get_rect(center=rect.center)
        return rot_image,rot_rect
class circle:
    def __init__(self, x, y):
        self.clicked = False
        self.r = 60
        self.realR = 40
        self.rr = 50
        self.size = 1
        self.ltime = 0
        self.color = [0, 0, 255]
        self.colorc = [0, 0, 0]
        self.coloro = [255, 255, 255]
        self.clicked = False
        self.d = True
        self.x = x
        self.y = y
        self.alpha = 0
        self.n = 0
        self.rect = pygame.Rect(self.x - self.realR,self.y - self.realR,self.realR*2,self.realR*2)
        self.dd = False

    def change_size(self, nsize):
        self.size = nsize ** 0.5
        self.rr = 50 + int(30*(self.size - 1))
    def draw_circle  (self):
        global life
        if self.d and (time - self.ltime) == 1:
            self.dd = True
            self.ltime = time
            pygame.draw.circle(screen1, self.colorc,(self.x,self.y), int(30*self.size))
            pygame.draw.circle(screen1, self.coloro,(self.x,self.y),self.rr, 3)
            if self.color[2] > 255//13 :

                self.color[2] -= 12
                self.color[1] += 12
                self.colorc[0] = int(self.color[0]*self.alpha)
                self.colorc[1] = int(self.color[1]*self.alpha)
                self.colorc[2] = int(self.color[2]*self.alpha)
                self.rr -= 1
                self.alpha += 0.05


            else:

                self.n += 1

                if self.n > 70:
                    self.alpha -= 0.09
                else:
                    self.alpha = 1

                self.colorc[0] = int(self.color[0]*self.alpha)
                self.colorc[1] = int(self.color[1]*self.alpha)
                self.colorc[2] = int(self.color[2]*self.alpha)
                self.coloro[0] = int(255*self.alpha)
                self.coloro[1] = int(255*self.alpha)
                self.coloro[2] = int(255*self.alpha)
            self.r -= 1
            if self.r < 2:

                self.d = False
                self.alpha = 0
                self.coloro = [255, 255, 255]
                self.n = 0
                self.dd = False
                if self.clicked == False:
                    life -= 20

beatmap = []
angle = 5

bgimg = ''
music = ''

color = [0,0,255]
score = 0
r = 10
time = 0
bgimg = bgimg.strip()
music = music.strip()
krest = pygame.image.load('data/krest.png')
scale = pygame.transform.scale(krest, (60,60))
gal = pygame.image.load('data/tr.png')
scale_g = pygame.transform.scale(gal, (60,60))
try:
    pygame.mixer.music.load(music)
except Exception:
    pass


d = False

mpos = [-100,-100]
krt = 0

draw_krest = False
gl = False

beats = []
for beat in beatmap:
    beats += [circle(beat[1], beat[2])]
    beats[-1].ltime = beat[0]
poz = []
scale_g.set_colorkey((255, 255, 255))
screen1.fill((0, 0, 0))

class MenuItem:
    def __init__(self, text, color, x, y):
        self.text = text
        self.color = color
        self.x, self.y = x, y
        self.xx, self.yy = self.x, self.y
        self.font = pygame.font.SysFont('Comic Sans MS', 20)
        self.margin = 5
        self.mm = 5
        self.size = 20
        self.ss = 20
        self.width, self.height = 200, 50
        self.ww, self. hh = self.width, self.height
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
    def inverse_color(self):
        return (255-self.color[0], 255-self.color[1], 255- self.color[2])
    def rup(self):
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
    def render(self):
        textsurface = self.font.render(self.text, False, self.color)
        pygame.draw.rect(screen, self.inverse_color(), self.rect)
        screen.blit(textsurface, (self.x + self.margin, self.y + self.height // 2 - self.margin*2))


    def onMouseDown(self, mx, my):
        if self.rect.collidepoint(mx, my):
            self.x -= 1
            self.y -= 1
            self.width += 2
            self.size += 1
            self.height += 2
            self.margin += 0.5
            self.font = pygame.font.SysFont('Comic Sans MS', self.size)
            self.rect = pygame.Rect(self.x, self.y, self.width, self.height)
        else:

            if self.x < self.xx:
                self.x += 1
            if self.y < self.yy:
                self.y += 1   
            if self.margin > self.mm:
                self.margin -= 0.5
            if self.width > self.ww:
                self.width -= 2
            if self.height > self.hh:
                self.height -= 2      
            if self.size > self.ss:
                self.size -= 1    
            self.font = pygame.font.SysFont('Comic Sans MS', self.size)
            self.rect = pygame.Rect(self.x, self.y, self.width, self.height)

    def check_click(self, mx, my):
        if self.rect.collidepoint(mx, my):
            self.onClick()
            return True
    def onClick(self):
        pass
is_start = True
l_show = False
clock = pygame.time.Clock()
menu_items = []
menu_items += [MenuItem('Levels', (255, 0, 0), 1000, 400)]
menu_items += [MenuItem('Info', (0, 255, 0), 1000, 500)]
menu_items += [MenuItem('Exit', (0, 0, 255), 1000, 600)]
running = True
level_info = []

with open('lvls.txt') as f:
    level_info = f.readlines()
levels = []
fnames = []
ii = -1
for s in level_info:
    ii += 1
    name, fname = s.split(' - ')
    levels += [MenuItem(name, (0, 0, 255), 1000, 400 + ii * 100)]
    fnames += [fname.strip()]
def quit():
    global running
    running = False
def show():
    global l_show, is_start
    l_show = True
    is_start = False
menu_items[-1].onClick = quit
menu_items[0].onClick = show
while running:
    screen1.fill((0, 0, 0))
    screen.fill((0, 0, 0))
    if playing:
        time += 1
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                if playing:
                    mpos = ()
                    f = False
                    mpos = event.pos
                    for i in beats:
                        if i.rect.collidepoint(event.pos) and i.dd and not(i.clicked):
                            i.clicked = True
                            f = True
                            break
                    if f:
                        life += 5
                        mpos = event.pos
                        gl = True
                    else:
                        life -= 5
                        draw_krest = True
                        mpos = event.pos
                pos = event.pos
                x1, y1 = pos[0], pos[1]
                if is_start:
                    for mi in menu_items:
                        mi.check_click(x1, y1)
                elif l_show:
                    nn = 0
                    for lvl in levels:
                        if lvl.check_click(x1, y1):
                            beatmap = []
                            life = 100
                            levelname = fnames[nn]
                            with open(levelname, "r") as f:
                                lines = f.readlines()
                                bgimg = 'data/' + lines[0]
                                music = 'data/' + lines[1]
                                for beat in lines[2:]:

                                    Ltime, x, y = beat.split('|')
                                    Ltime, x, y = int(Ltime), int(x), int(y)
                                    beatmap += [(Ltime, x, y)]

                            color = [0,0,255]
                            score = 0
                            r = 10
                            time = 0
                            bgimg = bgimg.strip()
                            music = music.strip()
                            image = pygame.image.load(bgimg)
                            image = pygame.transform.scale(image, (size[0],size[1]))
                            krest = pygame.image.load('data/krest.png')
                            scale = pygame.transform.scale(krest, (60,60))
                            gal = pygame.image.load('data/tr.png')
                            scale_g = pygame.transform.scale(gal, (60,60))
                            pygame.mixer.music.load(music)
                            mpos = [-100,-100]
                            krt = 0

                            draw_krest = False
                            gl = False
                            pygame.mixer.music.play(1)
                            beats = []
                            for beat in beatmap:
                                beats += [circle(beat[1], beat[2])]
                                beats[-1].ltime = beat[0]
                            print(beats)
                            poz = []
                            scale_g.set_colorkey((255, 255, 255))
                            screen1.fill((0, 0, 0))
                            playing = True
                            l_show = False
                            mainscreen = screen1
                            break
                        nn += 1
            if event.button == 5:
                if l_show:
                    if levels[0].y < 400:
                        for lvl in levels:
                            lvl.y += 15
                            lvl.rup()
            if event.button == 4:
                if l_show:
                    if levels[-1].y >= 400:
                        for lvl in levels:
                            lvl.y -= 15
                            lvl.rup()
    poz = pygame.mouse.get_pos()
    x, y = poz[0], poz[1]
    if playing:

        for beat in beats:
            beat.draw_circle()


        if draw_krest:
            if krt < 20:
                screen1.blit(scale, (mpos[0] - 25,mpos[1] - 25))
                krt += 1
            else:
                krt = 0
                draw_krest = False
        if gl:
            if krt < 20:
                screen1.blit(scale_g, (mpos[0] - 25,mpos[1] - 25))
                krt += 1
            else:
                krt = 0
                gl = False
        if life < 0:
            playing = False
            pygame.mixer.music.stop()
            mainscreen = screen
            l_show = True
        if beats[-1].ltime == time - 60:
            playing = False
            pygame.mixer.music.stop()
            mainscreen = screen
            l_show = True
    if is_start:
        for mi in menu_items:
            mi.onMouseDown(x, y)
            mi.render()
    if l_show:
        for lvl in levels:
            lvl.render()
            if lvl.rect.collidepoint(x, y):
                pygame.draw.rect(screen, (255, 255, 255), (lvl.x - 2, lvl.y - 2, 204, 54), 4)
        pygame.draw.rect(screen, (0, 0, 0), (995, 0, 215, 400))
        pygame.draw.rect(screen, (0, 0, 0), (995, 652, 215, 1024-652))
    pygame.draw.circle(screen, (255, 0, 255), (700, 500), 200)
    pygame.draw.circle(screen, (255, 255, 255), (700, 500), 202, 4)
    text = 'OSU'
    font = pygame.font.SysFont('Comic Sans MS', 80)
    textsurface = font.render(text, True, (255, 255, 255))
    screen.blit(textsurface, (620, 445))
    angle -= 5
    rect = cursor.get_rect(center=(poz[0] + 12, poz[1] + 12)) 
    surf, r = rot_center(cursor, rect, angle)    
    screen.blit(surf, r)
    screen1.blit(surf, r)
    pygame.display.flip()
    clock.tick(60)
    window.blit(mainscreen, (0, 0))
  
pygame.quit()

