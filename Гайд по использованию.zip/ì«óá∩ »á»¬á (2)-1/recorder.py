import pygame
pygame.mixer.init()
width, height = size = (1280, 960)
screen = pygame.display.set_mode(size, pygame.FULLSCREEN)
color = [0,0,255]
score = 0
r = 10
life = 100
time = 0
clock = pygame.time.Clock()
running = True
d = False


level = []
bgimg = 'winxbg.png'
pygame.mixer.music.load('pop_stars.mp3')
mus = 'pop_stars.mp3'
pygame.mixer.music.play(1) 
while running:
    time += 1
    screen.fill((0, 0, 0))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            pos = event.pos
            level += [(time - 20, pos[0],pos[1])]


    pygame.display.flip()
    clock.tick(60)
with open('Level2.osu', 'w') as f:
    f.write(bgimg+'\n')
    f.write(mus+'\n')
    for beat in level:
        time, x, y = beat
        f.write(str(time)+"|"+str(x)+'|'+str(y)+'\n')
pygame.mixer.music.stop()
pygame.quit()
